#!/bin/bash
# run_v15.sh — v15 出场几何消融 (7臂 x 54折全窗, ML_THREADS=26)
cd /root/rivermind-data/research-lab
export NTFY_TOPIC=xauusd-qv7m2zk9-res
say() { curl -s --max-time 20 -X POST "https://ntfy.sh/$NTFY_TOPIC" -d "$1" -H 'Title: v15' >/dev/null 2>&1 || true; }
say 'v15 出场消融启动: 7臂 (base/fixed/chandelier/bracket_str/scale_out/time_exit/atr_tight)'
ML_THREADS=26 python3 v15_exit.py > results_v15/master.out 2>&1
say "v15 出场消融完成 rc=$? (results_v15/exit_arms.json)"
